#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Classmate - Windows Deployment Script (Pre-built Bundle)

.DESCRIPTION
    Deploys the pre-built Classmate application to Windows.
    No Node.js build tools or source code required.
    Installs: PostgreSQL, Node.js (runtime), NSSM, IIS

.NOTES
    Run from the folder containing this script
    (same folder as api-dist, frontend, classmate_db_export.sql)

    Usage:
      Right-click Deploy-Classmate.ps1 -> "Run with PowerShell" (as Admin)
      OR from an Admin PowerShell terminal:
        Set-ExecutionPolicy Bypass -Scope Process -Force
        .\Deploy-Classmate.ps1
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ==============================================================================
# CONFIGURATION - Adjust these values before running
# ==============================================================================

$Config = @{
    DbName        = "classmate_db"
    DbUser        = "classmate_user"
    DbPassword    = "ClassmateDb@2024!"     # Change this!
    DbPort        = 5432
    SiteName      = "Classmate"
    SitePort      = 80
    IisSitePath   = "C:\inetpub\classmate"
    ApiPort       = 8080
    ServiceName   = "ClassmateAPI"
    SessionSecret = -join ((65..90) + (97..122) + (48..57) |
                      Get-Random -Count 40 |
                      ForEach-Object { [char]$_ })
    BundleRoot    = $PSScriptRoot
}

# ==============================================================================
# HELPERS
# ==============================================================================

function Write-Step { param($msg) Write-Host "`n>>> $msg" -ForegroundColor Cyan }
function Write-Ok   { param($msg) Write-Host "    [OK] $msg" -ForegroundColor Green }
function Write-Warn { param($msg) Write-Host "    [!!] $msg" -ForegroundColor Yellow }

function Invoke-Choco {
    param([string]$Package, [string[]]$Extra = @())
    $installed = choco list --local-only $Package 2>$null | Select-String $Package
    if ($installed) { Write-Ok "$Package already installed"; return }
    Write-Host "    Installing $Package..."
    choco install $Package -y --no-progress @Extra
    if ($LASTEXITCODE -ne 0) { throw "Failed to install $Package" }
    Write-Ok "$Package installed"
}

function Wait-ForPort {
    param([int]$Port, [int]$TimeoutSec = 30)
    $end = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $end) {
        try {
            $c = New-Object System.Net.Sockets.TcpClient("localhost", $Port)
            $c.Close(); return $true
        } catch { Start-Sleep 1 }
    }
    return $false
}

# ==============================================================================
# STEP 0 - Validate bundle contents
# ==============================================================================

Write-Step "Validating bundle contents"

foreach ($item in @("api-dist\index.mjs", "frontend\index.html", "classmate_db_export.sql")) {
    if (-not (Test-Path (Join-Path $Config.BundleRoot $item))) {
        Write-Host "    [FAIL] Missing: $item" -ForegroundColor Red
        Write-Host "    Make sure you run this script from inside the classmate-deploy folder." -ForegroundColor Red
        Write-Host "    Expected path: $(Join-Path $Config.BundleRoot $item)" -ForegroundColor Red
        exit 1
    }
}
Write-Ok "Bundle is complete at: $($Config.BundleRoot)"
Set-Location $Config.BundleRoot

# ==============================================================================
# STEP 1 - Chocolatey
# ==============================================================================

Write-Step "Checking Chocolatey"
if (-not (Get-Command choco -ErrorAction SilentlyContinue)) {
    Write-Host "    Installing Chocolatey..."
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
    Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
    $env:PATH += ";$env:ALLUSERSPROFILE\chocolatey\bin"
    Write-Ok "Chocolatey installed"
} else {
    Write-Ok "Chocolatey already available"
}

# ==============================================================================
# STEP 2 - Node.js runtime
# ==============================================================================

Write-Step "Installing Node.js LTS (runtime only - no build needed)"
Invoke-Choco "nodejs-lts"
$env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" +
            [System.Environment]::GetEnvironmentVariable("PATH", "User")
Write-Ok "Node.js: $(node --version)"

# ==============================================================================
# STEP 3 - PostgreSQL
# ==============================================================================

Write-Step "Installing PostgreSQL"
Invoke-Choco "postgresql16" "--params" "/Password:$($Config.DbPassword)"

$pgBin = "C:\Program Files\PostgreSQL\16\bin"
if (Test-Path $pgBin) {
    $env:PATH += ";$pgBin"
} else {
    $pg = Get-ChildItem "C:\Program Files\PostgreSQL" -Directory -ErrorAction SilentlyContinue |
          Sort-Object Name -Descending | Select-Object -First 1
    if ($pg) { $env:PATH += ";$($pg.FullName)\bin" }
}

$pgReady = Wait-ForPort -Port $Config.DbPort -TimeoutSec 60
if (-not $pgReady) {
    Write-Warn "PostgreSQL not responding - trying to start service..."
    Get-Service | Where-Object { $_.Name -like "postgresql*" } | Start-Service
    if (-not (Wait-ForPort -Port $Config.DbPort -TimeoutSec 30)) {
        throw "PostgreSQL failed to start on port $($Config.DbPort)"
    }
}
Write-Ok "PostgreSQL running on port $($Config.DbPort)"

# ==============================================================================
# STEP 4 - Create database and import data
# ==============================================================================

Write-Step "Setting up database"
$env:PGPASSWORD = $Config.DbPassword

if ((psql -U postgres -tAc "SELECT 1 FROM pg_roles WHERE rolname='$($Config.DbUser)'" 2>&1) -ne "1") {
    psql -U postgres -c "CREATE USER $($Config.DbUser) WITH PASSWORD '$($Config.DbPassword)';" | Out-Null
    Write-Ok "DB user '$($Config.DbUser)' created"
} else {
    Write-Ok "DB user '$($Config.DbUser)' already exists"
}

if ((psql -U postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$($Config.DbName)'" 2>&1) -ne "1") {
    psql -U postgres -c "CREATE DATABASE $($Config.DbName) OWNER $($Config.DbUser);" | Out-Null
    Write-Ok "Database '$($Config.DbName)' created"
} else {
    Write-Ok "Database '$($Config.DbName)' already exists"
}

psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE $($Config.DbName) TO $($Config.DbUser);" | Out-Null

Write-Host "    Importing data from classmate_db_export.sql..."
psql -U $Config.DbUser -d $Config.DbName -f (Join-Path $Config.BundleRoot "classmate_db_export.sql") 2>&1 | Out-Null
Write-Ok "Database imported"

$Config.DatabaseUrl = "postgresql://$($Config.DbUser):$($Config.DbPassword)@localhost:$($Config.DbPort)/$($Config.DbName)"

# ==============================================================================
# STEP 5 - Enable IIS
# ==============================================================================

Write-Step "Enabling IIS features"

$features = @(
    "IIS-WebServerRole","IIS-WebServer","IIS-CommonHttpFeatures","IIS-StaticContent",
    "IIS-DefaultDocument","IIS-DirectoryBrowsing","IIS-HttpErrors","IIS-ApplicationDevelopment",
    "IIS-ISAPIExtensions","IIS-ISAPIFilter","IIS-WebServerManagementTools","IIS-ManagementConsole",
    "IIS-HttpCompressionStatic","IIS-RequestFiltering","IIS-HttpLogging"
)

foreach ($f in $features) {
    $state = (Get-WindowsOptionalFeature -Online -FeatureName $f -ErrorAction SilentlyContinue).State
    if ($state -ne "Enabled") {
        Enable-WindowsOptionalFeature -Online -FeatureName $f -NoRestart -All | Out-Null
    }
}
Write-Ok "IIS features enabled"

# ==============================================================================
# STEP 6 - URL Rewrite and ARR
# ==============================================================================

Write-Step "Installing IIS URL Rewrite and ARR modules"

if (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\IIS Extensions\URL Rewrite")) {
    $msi = "$env:TEMP\urlrewrite2.msi"
    Invoke-WebRequest -Uri "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi" -OutFile $msi -UseBasicParsing
    Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Wait
    Write-Ok "URL Rewrite installed"
} else { Write-Ok "URL Rewrite already installed" }

if (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\IIS Extensions\Application Request Routing")) {
    $msi = "$env:TEMP\ARRv3_0.msi"
    Invoke-WebRequest -Uri "https://download.microsoft.com/download/E/9/8/E9849D6A-020E-47E4-9FD0-A023E99B54EB/requestRouter_amd64.msi" -OutFile $msi -UseBasicParsing
    Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Wait
    Write-Ok "ARR installed"
} else { Write-Ok "ARR already installed" }

Import-Module WebAdministration -ErrorAction SilentlyContinue
$arrProxy = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" `
    -filter "system.webServer/proxy" -name "enabled" -ErrorAction SilentlyContinue
if ($arrProxy.Value -ne $true) {
    Set-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" `
        -filter "system.webServer/proxy" -name "enabled" -value $true -ErrorAction SilentlyContinue
}
Write-Ok "ARR proxy enabled"

# ==============================================================================
# STEP 7 - Copy frontend to IIS
# ==============================================================================

Write-Step "Deploying frontend to IIS"

if (-not (Test-Path $Config.IisSitePath)) {
    New-Item -ItemType Directory -Path $Config.IisSitePath -Force | Out-Null
}

Copy-Item -Path (Join-Path $Config.BundleRoot "frontend\*") -Destination $Config.IisSitePath -Recurse -Force
Write-Ok "Frontend files copied to $($Config.IisSitePath)"

$webConfig = @"
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="API Proxy" stopProcessing="true">
          <match url="^api/(.*)" />
          <action type="Rewrite" url="http://localhost:$($Config.ApiPort)/api/{R:1}" />
        </rule>
        <rule name="SPA Fallback" stopProcessing="true">
          <match url=".*" />
          <conditions logicalGrouping="MatchAll">
            <add input="{REQUEST_FILENAME}" matchType="IsFile"      negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="/index.html" />
        </rule>
      </rules>
    </rewrite>
    <staticContent>
      <mimeMap fileExtension=".json"  mimeType="application/json" />
      <mimeMap fileExtension=".webp"  mimeType="image/webp" />
      <mimeMap fileExtension=".woff"  mimeType="font/woff" />
      <mimeMap fileExtension=".woff2" mimeType="font/woff2" />
    </staticContent>
    <httpProtocol>
      <customHeaders>
        <add name="X-Content-Type-Options" value="nosniff" />
        <add name="X-Frame-Options"        value="SAMEORIGIN" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
"@
Set-Content -Path (Join-Path $Config.IisSitePath "web.config") -Value $webConfig -Encoding UTF8
Write-Ok "IIS web.config written"

# ==============================================================================
# STEP 8 - Create IIS site
# ==============================================================================

Write-Step "Configuring IIS website"
Import-Module WebAdministration

if (Get-WebSite -Name $Config.SiteName -ErrorAction SilentlyContinue) {
    Write-Warn "Site '$($Config.SiteName)' exists - removing and recreating"
    Remove-WebSite -Name $Config.SiteName
}

$defaultSite = Get-WebSite -Name "Default Web Site" -ErrorAction SilentlyContinue
if ($defaultSite -and $defaultSite.State -eq "Started" -and $Config.SitePort -eq 80) {
    Write-Warn "Stopping Default Web Site (conflicts on port 80)"
    Stop-WebSite -Name "Default Web Site"
}

New-WebSite -Name $Config.SiteName -Port $Config.SitePort -PhysicalPath $Config.IisSitePath -Force | Out-Null
Start-WebSite -Name $Config.SiteName
Write-Ok "IIS site '$($Config.SiteName)' running on port $($Config.SitePort)"

# ==============================================================================
# STEP 9 - Register API as Windows Service via NSSM
# ==============================================================================

Write-Step "Installing NSSM"
Invoke-Choco "nssm"

Write-Step "Registering Classmate API as a Windows Service"

$nodePath = (Get-Command node).Source
$apiIndex = Join-Path $Config.BundleRoot "api-dist\index.mjs"

$existingSvc = Get-Service -Name $Config.ServiceName -ErrorAction SilentlyContinue
if ($existingSvc) {
    Write-Warn "Service '$($Config.ServiceName)' exists - stopping and removing"
    if ($existingSvc.Status -eq "Running") { nssm stop $Config.ServiceName confirm }
    nssm remove $Config.ServiceName confirm
    Start-Sleep 2
}

nssm install $Config.ServiceName $nodePath $apiIndex
nssm set $Config.ServiceName AppDirectory       $Config.BundleRoot
nssm set $Config.ServiceName AppStdout          "C:\Logs\classmate-api.log"
nssm set $Config.ServiceName AppStderr          "C:\Logs\classmate-api-error.log"
nssm set $Config.ServiceName AppRotateFiles      1
nssm set $Config.ServiceName AppRotateSeconds    86400
nssm set $Config.ServiceName Description        "Classmate API Server"
nssm set $Config.ServiceName Start              SERVICE_AUTO_START

$envBlock = "PORT=$($Config.ApiPort)`nDATABASE_URL=$($Config.DatabaseUrl)`nNODE_ENV=production`nSESSION_SECRET=$($Config.SessionSecret)"
nssm set $Config.ServiceName AppEnvironmentExtra $envBlock

New-Item -ItemType Directory -Path "C:\Logs" -Force | Out-Null
nssm start $Config.ServiceName

Write-Host "    Waiting for API to start on port $($Config.ApiPort)..."
if (Wait-ForPort -Port $Config.ApiPort -TimeoutSec 45) {
    Write-Ok "API is responding on port $($Config.ApiPort)"
} else {
    Write-Warn "API did not respond in time - check C:\Logs\classmate-api-error.log"
}

# ==============================================================================
# STEP 10 - Firewall
# ==============================================================================

Write-Step "Adding Windows Firewall rule"
if (-not (Get-NetFirewallRule -DisplayName "Classmate HTTP" -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName "Classmate HTTP" -Direction Inbound `
        -Protocol TCP -LocalPort $Config.SitePort -Action Allow | Out-Null
    Write-Ok "Firewall rule added for port $($Config.SitePort)"
} else {
    Write-Ok "Firewall rule already exists"
}

# ==============================================================================
# DONE
# ==============================================================================

$ip = (Get-NetIPAddress -AddressFamily IPv4 |
       Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.*" } |
       Select-Object -First 1).IPAddress

Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  CLASSMATE DEPLOYED SUCCESSFULLY" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  App URL    : http://localhost:$($Config.SitePort)" -ForegroundColor White
if ($ip) {
Write-Host "  Network URL: http://${ip}:$($Config.SitePort)" -ForegroundColor White
}
Write-Host ""
Write-Host "  Database   : $($Config.DbName) @ localhost:$($Config.DbPort)" -ForegroundColor White
Write-Host "  API Service: $($Config.ServiceName) (port $($Config.ApiPort), internal only)" -ForegroundColor White
Write-Host "  Logs       : C:\Logs\classmate-api.log" -ForegroundColor White
Write-Host ""
Write-Host "  Useful commands:" -ForegroundColor Yellow
Write-Host "    nssm restart $($Config.ServiceName)   - restart the API" -ForegroundColor Gray
Write-Host "    nssm status  $($Config.ServiceName)   - check API status" -ForegroundColor Gray
Write-Host "    iisreset                      - restart IIS" -ForegroundColor Gray
Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
